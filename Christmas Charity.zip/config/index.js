module.exports = {
    PORT: 3000,
    DATABASE_CONNECTION_STRING: 'mongodb://localhost:27017/charity-christmas-DB',
    TOKEN_SECRET: 'this is very secure',
    COOKIE_NAME: 'SESSION_TOKEN'
}